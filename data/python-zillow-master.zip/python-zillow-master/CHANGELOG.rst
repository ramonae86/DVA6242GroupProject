0.3.0
=====

Released: TBD

0.2.0
=====

Released: 2018-03-29

- Add ``GetDeepComps`` API method
- Fix Python 3 compatibility
- Fix ``zestimate`` typos
- Use HTTPS for API requests
